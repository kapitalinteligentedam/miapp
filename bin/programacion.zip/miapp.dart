import "dart:io";
import "database.dart";
import "usuario.dart";
import "menus.dart";

main() async {
  await DataBase.instalarBBDD();

  String opcion = Menus.inicio();

  switch (opcion) {
    case "1":
      Menus.registro();
      break;
    case "2":
      bool logueado = false;
      Usuario usuario = Usuario();
      do {
        stdout.writeln("Introduce tu nombre de usuario");
        String nombre = stdin.readLineSync() ?? 'error';
        stdout.writeln("Ahora introduce tu contraseña");
        String password = stdin.readLineSync() ?? 'error';
        if (nombre == usuario.user && password == usuario.password) {
          stdout.writeln("Login correcto");
          logueado = true;
        } else {
          stdout.writeln("Login incorrecto");
        }
      } while (logueado == false);

      do {
        stdout.writeln("""Bienvenido, ${usuario.user}, elige una opción:
  1. Completar datos
  2. Calcular IMC""");
        int? opcion = int.tryParse(stdin.readLineSync() ?? '0');
        if (opcion == 1) {
          stdout.writeln("Introduce tu edad");
          usuario.edad = int.parse(stdin.readLineSync() ?? '0');
          stdout.writeln("Introduce tus apellidos");
          usuario.apellidos = stdin.readLineSync();
          stdout.writeln("Introduce tu altura en metros");
          usuario.altura = double.parse(stdin.readLineSync() ?? '0');
          stdout.writeln("Introduce tu peso en kg");
          usuario.peso = double.parse(stdin.readLineSync() ?? '0');
        } else if (opcion == 2) {
          if (usuario.altura != null && usuario.peso != null) {
            double imc = usuario.calcularIMC();
            stdout.writeln("Tu IMC es $imc");
          } else {
            stdout.writeln("Debes completar tus datos primero");
          }
        } else {
          break;
        }
      } while (true);
      break;
  }
}
