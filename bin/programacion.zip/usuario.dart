import "dart:io";
import "database.dart";

class Usuario {
  String _user = "carlos";
  String _password = "pass";
  int? _edad;
  String? _apellidos;
  double? _altura;
  double? _peso;

  String get user => _user;
  String get password => _password;
  int? get edad => _edad;
  String? get apellidos => _apellidos;
  double? get altura => _altura;
  double? get peso => _peso;

  set user(String user) {
    _user = user;
  }

  set password(String password) {
    _password = password;
  }

  set edad(int? edad) {
    _edad = edad;
  }

  set apellidos(String? apellidos) {
    _apellidos = apellidos;
  }

  set altura(double? altura) {
    _altura = altura;
  }

  set peso(double? peso) {
    _peso = peso;
  }

  double calcularIMC() => _peso! / (_altura! * _altura!);

  static Future<bool> comprobarSiExiste(String nombre) async {
    bool existe = true;
    var conn;
    try {
      conn = await DataBase.obtenerConexion();
      var registros =
          await conn.query("SELECT * FROM usuarios WHERE nombre = ?", [nombre]);
      if (registros.length == 0) {
        existe = false;
      }
    } catch (e) {
      print(e);
    } finally {
      conn.close();
    }
    return existe;
  }

  Future<bool> save() async {
    bool guardado = false;
    var conn;
    try {
      conn = await DataBase.obtenerConexion();
      await conn.query("INSERT INTO usuarios (nombre,password) VALUES(?,?)",
          [user, password]);
      stdout.writeln("Usuario insertado con éxito");
      guardado = true;
    } catch (e) {
      print(e);
    } finally {
      conn.close();
    }
    return guardado;
  }
}
